EARTH BREEZE - PARCEL SHIPMENT DATA PACKAGE
Carrier-invoiced shipment detail, 25 April - 25 July 2026

WHAT THIS IS
Shipment-level detail taken directly from carrier parcel backup reports across 14
weekly consolidated invoices. These are invoiced values, not estimates: actual
weight, package dimensions, dimensional weight, billed weight and the billed-weight
basis are exactly what the carrier charged against.

444,220 billable shipments. 16,163 adjustment rows are retained but flagged
(is_adjustment = Y) so they can be excluded from volume and cost modelling.

WHY BILLED WEIGHT MATTERS HERE
  31.1% of shipments bill on DIMENSIONAL weight, not actual weight.
  Mean actual weight   1.28 lb
  Mean BILLED weight   1.81 lb   (+42.2%)

Earth Breeze's own operational systems record catalog weight (the sum of line-item
weights). That figure understates the billable basis by roughly 40%. Rate cards must
be quoted against BILLED weight, and bidders must state the dimensional divisor and
rounding convention they will apply. A card quoted on actual or catalog weight cannot
be compared against one quoted on billed weight, and will be treated as incomplete.

FILES
  1. EarthBreeze_Parcel_Shipment_Profile_Apr-Jul2026.xlsx
     Zone x billed weight distribution, service mix, monthly volume, destination
     states, billing basis split, and the 30 most common carton sizes.
     The Zone x Billed Weight tab is the volume basis Earth Breeze applies to every
     rate card received - price against it directly.

  2. EarthBreeze_Shipment_Level_Detail_Apr-Jul2026.csv  (444,306 rows)
     One row per shipment: ship date, service level, zone, destination city/state/ZIP,
     origin ZIP, item qty, actual weight (lb), length/width/height (in), dim weight,
     billed weight, billed-weight basis, SKU count, adjustment flag.

  3. EarthBreeze_Order_Line_Detail_Apr-Jul2026.csv  (1,097,095 rows)
     One row per order-SKU: order reference, ship date, service level, zone,
     destination state, SKU, units, order item qty, billed weight.
     Use this for order profile, fast/slow-moving SKUs, items commonly picked
     together, and kit/bundle pricing.

PRIVACY AND SCOPE
Order references are pseudonymised and cannot be reversed. No customer names,
addresses, email addresses or phone numbers are included. All carrier rates, charges,
surcharges and invoice amounts have been removed - this package describes volume and
physical characteristics only.

NOTES AND LIMITATIONS
  - Period is 25 April - 25 July 2026, covering the CVGs001 (Hebron, KY) facility.
  - Zone "US" denotes mail-class shipments (Marketing Mail Flats), which are not
    zone-rated; they are 15.3% of shipments.
  - Dimensions are as recorded by the carrier at the time of shipment.
  - Some shipments appear with multiple fee lines on the invoice; these are collapsed
    to one row per shipment here.

Questions on this package should be submitted through the Q&A section of the portal
so that answers are published to all bidders.
